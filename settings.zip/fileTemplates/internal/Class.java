#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author robin
 * @date ${YEAR}年${MONTH}月${DAY}日 ${TIME}
 */
public class ${NAME} {
}
